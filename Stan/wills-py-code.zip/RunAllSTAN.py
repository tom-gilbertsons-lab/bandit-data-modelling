import matplotlib.pyplot as plt
import pystan
import pandas as pd
import numpy as np
import os
import arviz
import pickle
import sys
import csv
import pdb

def process_model(model_name, model_file, param_names):
    # Compile the model
    sm = pystan.StanModel(file=model_file)
    
    # Sample posterior
    fit = sm.sampling(data=my_data, iter=iteration, chains=chain)
    params = fit.extract()
    
    # Squeeze and save each parameter
    for name in param_names:
        param_values = np.squeeze(params[name])
        df = pd.DataFrame(param_values)
        df.to_csv(os.path.join(data_path, model_name, f"{name}.csv"))

# Set up directories
main_path = '/home/will/Desktop/WG_Research/Apathy/Ap_new' #Change this depending upon where the main folder is found
scripts_path = os.path.join(main_path, 'Scripts/Python')
data_path_load = os.path.join(main_path, 'In_Scanner') # Either 'In_Scanner' or 'Out_Scanner'
data_path = os.path.join(data_path_load, 'parameters')

# Define model parameters
nSubjects = 59 # Change this dependent upon how many subjects in the group - likely this will be 59 or 75 dependent upon In or Out scanner
iteration = 5000 # In this version, split into half warm-up which is discarded and half samples to be kept
chain = 4
nTrials = 300

# Load data
df = pd.read_csv(os.path.join(data_path_load, 'CompleteData.csv'))
print(df)

# Format data for MCMC
choice = df['Choice'].to_numpy()
reward = df['Reward'].to_numpy()
choice = np.reshape(choice,(nSubjects, nTrials))
reward = np.reshape(reward,(nSubjects, nTrials))
my_data = {'nSubjects': nSubjects, 'nTrials': nTrials,'choice':choice,'reward':reward}

# Print options
np.set_printoptions(threshold=sys.maxsize)

# Process models
#model_files = ['BayesSM_model.stan', 'BayesSME_model.stan', 'BayesSMP_model.stan', 'BayesSMEP_model.stan', 'AlphaSM_model.stan', 'AlphaSME_model.stan', 'AlphaSMP_model.stan', 'AlphaSMEP_model.stan']
#model_names = ['BayesSM', 'BayesSME', 'BayesSMP', 'BayesSMEP', 'AlphaSM', 'AlphaSME', 'AlphaSMP', 'AlphaSMEP']
#param_names = [['beta'], ['beta', 'phi'], ['beta', 'persev'], ['beta', 'phi', 'persev'], ['alpha', 'beta'], ['alpha', 'beta', 'phi'], ['alpha', 'beta', 'persev'], ['alpha', 'beta', 'phi', 'persev']]

model_files = ['BayesSM_model.stan', 'BayesSME_model.stan', 'BayesSMP_model.stan', 'BayesSMEP_model.stan', 'AlphaSM_model.stan', 'AlphaSME_model.stan', 'AlphaSMP_model.stan', 'AlphaSMEP_model.stan']
model_names = ['BayesSM', 'BayesSME', 'BayesSMP', 'BayesSMEP', 'AlphaSM', 'AlphaSME', 'AlphaSMP', 'AlphaSMEP']
param_names = [['beta'], ['beta', 'phi'], ['beta', 'persev'], ['beta', 'phi', 'persev'], ['alpha', 'beta'], ['alpha', 'beta', 'phi'], ['alpha', 'beta', 'persev'], ['alpha', 'beta', 'phi', 'persev']]

for model_file, model_name, param_name in zip(model_files, model_names, param_names):
    process_model(model_name, os.path.join(scripts_path, model_file), param_name)
