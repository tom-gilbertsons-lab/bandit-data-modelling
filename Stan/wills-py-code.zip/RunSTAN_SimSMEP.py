import matplotlib.pyplot as plt
import pystan
import pandas as pd
import numpy as np
import os
import arviz
import pickle
import sys
import csv
import pdb

main_path = '/home/will/Documents/Apathy/STAN_Loo_v4'
scripts_path = main_path + '/Scripts/Python'
data_path_load = main_path + '/Simulation_Full'
data_path = data_path_load + '/parameters'
bayesSMEP_path = data_path +'/BayesSMEP'
simsave_path = data_path_load + '/Simulation/10'

nSubjects = 134
iteration = 1
nTrials = 300

os.chdir(data_path_load)
#1. Load data
re=pd.read_csv('Reward.csv')
reward = re.to_numpy()

par = pd.read_csv('Parameters.csv')
beta = par['beta'].values
phi = par['phi'].values
per = par['per'].values
print(par)

#2 Format for MCMC
# reward = np.reshape(reward,(nTrials,4)) #see if this is required

my_data = {
    'nSubjects': nSubjects,
    'nTrials': nTrials,
    'reward':reward,
    'beta':beta,
    'phi':phi,
    'persev':per
    }

np.set_printoptions(threshold=sys.maxsize)

#3 Bayes SMEP simulation
os.chdir(scripts_path)
sim_model = pystan.StanModel(file='BayesSMEP_model_simulation.stan')
#Sample Posterior
simulated = sim_model.sampling(data=my_data, iter=iteration, chains=1, algorithm="Fixed_param")
choice_sim = simulated.extract()

choice = choice_sim['choice']
reward_obt = choice_sim['reward_obt']

choice = np.squeeze(choice)
reward_obt = np.squeeze(reward_obt)


os.chdir(simsave_path)

Cdf = pd.DataFrame(choice)
Cdf.to_csv("Choice.csv")
Rdf = pd.DataFrame(reward_obt)
Rdf.to_csv("reward_obt.csv")

